﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using Vega.USiteBuilder;

namespace $rootnamespace$
{
    [MemberType]
    public class $safeitemname$ : MemberTypeBase
    {
        [MemberTypeProperty(UmbracoPropertyType.Textstring)]
        public string HelloWorld { get; set; }
    }
}
