﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using Vega.USiteBuilder;

namespace $rootnamespace$
{$classtipscomment$
    [DocumentType]
    public class $safeitemname$ : $documenttypebase$
    {$propertytipscomment$
        [DocumentTypeProperty(UmbracoPropertyType.Textstring)]
        public string HelloWorld { get; set; }
    }
}
